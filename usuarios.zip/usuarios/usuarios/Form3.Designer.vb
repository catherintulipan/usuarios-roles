﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMenú
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LbBienvenido = New System.Windows.Forms.Label()
        Me.GridUsuarios = New System.Windows.Forms.DataGridView()
        Me.BtnActivar = New System.Windows.Forms.Button()
        Me.BtnCambiarClave = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtNuevaClave = New System.Windows.Forms.TextBox()
        CType(Me.GridUsuarios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LbBienvenido
        '
        Me.LbBienvenido.AutoSize = True
        Me.LbBienvenido.Font = New System.Drawing.Font("Modern No. 20", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LbBienvenido.Location = New System.Drawing.Point(27, 25)
        Me.LbBienvenido.Name = "LbBienvenido"
        Me.LbBienvenido.Size = New System.Drawing.Size(115, 24)
        Me.LbBienvenido.TabIndex = 0
        Me.LbBienvenido.Text = "Bienvenido"
        '
        'GridUsuarios
        '
        Me.GridUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridUsuarios.Location = New System.Drawing.Point(31, 67)
        Me.GridUsuarios.Name = "GridUsuarios"
        Me.GridUsuarios.Size = New System.Drawing.Size(240, 150)
        Me.GridUsuarios.TabIndex = 1
        '
        'BtnActivar
        '
        Me.BtnActivar.Location = New System.Drawing.Point(42, 270)
        Me.BtnActivar.Name = "BtnActivar"
        Me.BtnActivar.Size = New System.Drawing.Size(97, 23)
        Me.BtnActivar.TabIndex = 2
        Me.BtnActivar.Text = "Activar"
        Me.BtnActivar.UseVisualStyleBackColor = True
        '
        'BtnCambiarClave
        '
        Me.BtnCambiarClave.Location = New System.Drawing.Point(159, 270)
        Me.BtnCambiarClave.Name = "BtnCambiarClave"
        Me.BtnCambiarClave.Size = New System.Drawing.Size(101, 23)
        Me.BtnCambiarClave.TabIndex = 3
        Me.BtnCambiarClave.Text = "Cambiar clave"
        Me.BtnCambiarClave.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 236)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(142, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Ingrese la nueva contraseña"
        '
        'TxtNuevaClave
        '
        Me.TxtNuevaClave.Location = New System.Drawing.Point(171, 233)
        Me.TxtNuevaClave.Name = "TxtNuevaClave"
        Me.TxtNuevaClave.Size = New System.Drawing.Size(100, 20)
        Me.TxtNuevaClave.TabIndex = 5
        '
        'FrmMenú
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(300, 450)
        Me.Controls.Add(Me.TxtNuevaClave)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnCambiarClave)
        Me.Controls.Add(Me.BtnActivar)
        Me.Controls.Add(Me.GridUsuarios)
        Me.Controls.Add(Me.LbBienvenido)
        Me.Name = "FrmMenú"
        Me.Text = "Menú"
        CType(Me.GridUsuarios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LbBienvenido As Label
    Friend WithEvents GridUsuarios As DataGridView
    Friend WithEvents BtnActivar As Button
    Friend WithEvents BtnCambiarClave As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtNuevaClave As TextBox
End Class
