﻿Imports MySql.Data.MySqlClient
Public Class FrmLogin
    Dim conexion As MySqlConnection = New MySqlConnection
    Dim cmd As New MySqlCommand
    Sub ActualizarSelect()


    End Sub
    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        If (TxtUsuario.Text = "" Or TxtContraseña.Text = "") Then
            MsgBox("Ingrese todos los datos.")
        Else


            conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"

            Dim ds As DataSet = New DataSet
            Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter

            Try
                conexion.Open()
                'MsgBox("Nos conectamos")
                cmd.Connection = conexion

                cmd.CommandText = "SELECT * FROM usuarios"
                adaptador.SelectCommand = cmd
                adaptador.Fill(ds, "Tabla")
                FrmMenú.GridUsuarios.DataSource = ds
                FrmMenú.GridUsuarios.DataMember = "Tabla"

                FrmMenú.Show()

                conexion.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If



    End Sub

    Private Sub BtnNuevoUsuario_Click(sender As Object, e As EventArgs) Handles BtnNuevoUsuario.Click
        FrmRegistro.Show()

    End Sub

    Private Sub FrmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub TxtUsuario_TextChanged(sender As Object, e As EventArgs) Handles TxtUsuario.TextChanged

    End Sub
End Class
