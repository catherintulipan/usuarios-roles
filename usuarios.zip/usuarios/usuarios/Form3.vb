﻿Imports MySql.Data.MySqlClient
Public Class FrmMenú
    Dim conexion As MySqlConnection = New MySqlConnection
    Dim cmd As New MySqlCommand
    Sub ActualizarSelect()


    End Sub

    Private Sub FrmMenú_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Nombre As String

        Nombre = FrmLogin.TxtUsuario.Text

        LbBienvenido.Text = "Bienvenido " + Nombre 


    End Sub

    Private Sub GridUsuarios_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles GridUsuarios.CellContentClick

    End Sub

    Private Sub GridUsuarios_SelectionChanged(sender As Object, e As EventArgs) Handles GridUsuarios.SelectionChanged
        If (GridUsuarios.SelectedRows.Count > 0) Then
            FrmLogin.TxtUsuario.Text = GridUsuarios.Item("nombre", GridUsuarios.SelectedRows(0).Index).Value
            FrmLogin.TxtContraseña.Text = GridUsuarios.Item("pass", GridUsuarios.SelectedRows(0).Index).Value


        End If
    End Sub

    Private Sub BtnCambiarClave_Click(sender As Object, e As EventArgs) Handles BtnCambiarClave.Click
        conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"

        Dim ds As DataSet = New DataSet
        Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter

        Try
            conexion.Open()
            'MsgBox("Nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "UPDATE usuarios SET pass=@pass WHERE idUsusario=@idUsuario "
            cmd.Prepare()

            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@pass", TxtNuevaClave.Text)
            cmd.ExecuteNonQuery()
            TxtNuevaClave.Clear()

            conexion.Close()
            ActualizarSelect()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BtnActivar_Click(sender As Object, e As EventArgs) Handles BtnActivar.Click

        conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"


        Try
            conexion.Open()
            'MsgBox("Nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "UPDATE usuarios SET  "
            cmd.Prepare()

            conexion.Close()
            ActualizarSelect()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
End Class