﻿Imports MySql.Data.MySqlClient
Public Class FrmRegistro
    Dim conexion As MySqlConnection = New MySqlConnection
    Dim cmd As New MySqlCommand
    Sub ActualizarSelect()


    End Sub

    Private Sub BtnAceptar_Click(sender As Object, e As EventArgs) Handles BtnAceptar.Click
        If (TxtNombre.Text = "" Or TxtContraseña.Text = "" Or TxtRepContraseña.Text = "") Then
            MsgBox("Ingrese todos los datos.")

        Else
            Dim ds As DataSet = New DataSet
            Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter

            conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"

            Try

                conexion.Open()
                'MsgBox("Nos conectamos")
                cmd.Connection = conexion

                cmd.CommandText = "INSERT INTO usuarios (nombre, pass, idRol) VALUE (@nombre, @pass, 3)"
                cmd.Prepare()



                cmd.Parameters.AddWithValue("@nombre", TxtNombre.Text)
                cmd.Parameters.AddWithValue("@pass", TxtContraseña.Text)
                cmd.ExecuteNonQuery()
                TxtNombre.Clear()
                TxtContraseña.Clear()
                TxtRepContraseña.Clear()

                cmd.CommandText = "SELECT * FROM usuarios"
                adaptador.SelectCommand = cmd
                adaptador.Fill(ds, "Tabla")
                FrmMenú.GridUsuarios.DataSource = ds
                FrmMenú.GridUsuarios.DataMember = "Tabla"

                FrmMenú.Show()

                conexion.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try


        End If


    End Sub

    Private Sub FrmRegistro_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnCancelar_Click(sender As Object, e As EventArgs) Handles BtnCancelar.Click


    End Sub
End Class